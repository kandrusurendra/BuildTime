﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Charting = System.Windows.Forms.DataVisualization.Charting;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int count = 1;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void InitChart()
        {            
            //BuildGraphChart.Series.Add(new Charting.Series());
            //BuildGraphChart.Series[0].ChartType = Charting.SeriesChartType.BoxPlot;
            //BuildGraphChart.Series[0]["BoxPlotShowMedian"] = "false";
            //BuildGraphChart.Series[0]["BoxPlotShowAverage"] = "false";
            //BuildGraphChart.Series[0]["BoxPlotShowUnusualValues"] = "false";
            //BuildGraphChart.Series[0].YValuesPerPoint = 4;
            //BuildGraphChart.Series[0].Points.AddXY("aaa", new object[] { 5.1, 9, 5, 9 });
            //BuildGraphChart.Series[0].Points.AddXY("bbb", new object[] { 9.1, 10, 9, 10 });
        }

        private void TextBox_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            count += 1;

            double x = count;
            double y = x + 3;

            BuildGraphChart.Series.Clear();
            BuildGraphChart.Series.Add(new Charting.Series());
            BuildGraphChart.Series[0].ChartType = Charting.SeriesChartType.BoxPlot;
            BuildGraphChart.Series[0]["BoxPlotShowMedian"] = "false";
            BuildGraphChart.Series[0]["BoxPlotShowAverage"] = "false";
            BuildGraphChart.Series[0]["BoxPlotShowUnusualValues"] = "false";
            BuildGraphChart.Series[0].YValuesPerPoint = 4;
            BuildGraphChart.Series[0].Points.AddXY("aaa", new object[] { x + 0.1, x + 4, x, x + 4 });
            BuildGraphChart.Series[0].Points.AddXY("bbb", new object[] { y + 0.1, y + 4, y, y + 4 });
        }
    }
}
